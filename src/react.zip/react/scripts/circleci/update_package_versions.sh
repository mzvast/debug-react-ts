#!/bin/bash

set -e

node ./scripts/release/ci-update-package-versions.js
